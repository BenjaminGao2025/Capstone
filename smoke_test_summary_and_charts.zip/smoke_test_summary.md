# LLM Scheduling Smoke Test Summary

## 1. Experiment purpose

This smoke test verifies that the local vLLM-LTR pipeline can run end-to-end on RunPod before launching the full Llama-3-8B reproduction. The goal is functional validation rather than a statistically meaningful performance claim.

The tested comparison is:

- **FCFS**: vLLM first-come-first-served baseline.
- **LTR / opt-xxx**: predictor-based scheduling using the `opt-xxx` schedule type and an OPT predictor configuration.

## 2. Environment and workload

- GPU: NVIDIA GeForce RTX 3090 24GB
- Python: 3.11.15
- PyTorch: 2.2.1+cu121
- CUDA visible to PyTorch: 12.1
- vLLM version: 0.4.1
- Test model: `facebook/opt-1.3b`
- Dataset trace: `lmsys-Meta-Llama-3-8B-Instruct-t1.0-s0-18192-c10000-rFalse.jsonl`
- Number of prompts: 20
- Request rate: 2.0 qps
- Output length setting: 128 tokens

## 3. Main results

| Metric | FCFS | LTR / opt-xxx |
|---|---:|---:|
| Completed requests | 20/20 | 20/20 |
| Request throughput | 1.5997 req/s | 1.5748 req/s |
| Mean TTFT | 1474.0 ms | 370.2 ms |
| P99 TTFT | 4731.9 ms | 1925.1 ms |
| Mean TPOT | 13.74 ms | 18.50 ms |
| P99 TPOT | 23.06 ms | 20.97 ms |
| Derived mean request latency | 2.82 s | 2.35 s |

## 4. Interpretation

Both schedulers completed all 20 requests, so the experiment confirms that the serving server, benchmark client, LMSYS trace, and result-writing pipeline are working.

In this small smoke test, LTR / opt-xxx reduced mean TTFT by about **74.9%** and p99 TTFT by about **59.3%** compared with FCFS. However, FCFS had slightly higher request throughput by about **1.6%**, and LTR / opt-xxx had higher mean TPOT by about **34.6%**.

This result should be reported as a **functional smoke test**, not as the final performance claim. The test uses `facebook/opt-1.3b`, only 20 prompts, and one request rate. The formal reproduction still requires the larger `Meta-Llama-3-8B-Instruct` workload and a rate sweep.

## 5. Key commands used

### FCFS server

```bash
CUDA_VISIBLE_DEVICES=0 python -m vllm.entrypoints.openai.api_server \
  --model facebook/opt-1.3b \
  --swap-space 16 \
  --disable-log-requests \
  --schedule-type fcfs \
  --enable-chunked-prefill \
  --enforce-eager \
  --port 3343 &
```

### FCFS benchmark

```bash
DATASET=$(ls lmsys-Meta-Llama-3-8B-Instruct-*c10000*.jsonl | head -n 1)

python benchmark_serving_real.py \
  --backend vllm \
  --model facebook/opt-1.3b \
  --tokenizer facebook/opt-1.3b \
  --dataset "$DATASET" \
  --num-prompts 20 \
  --request-time 30 \
  --schedule-type fcfs \
  --output-len 128 \
  --request-rate 2 \
  --result-dir RESULTS \
  --port 3343
```

### LTR / opt-xxx server

```bash
CUDA_VISIBLE_DEVICES=0 python -m vllm.entrypoints.openai.api_server \
  --model facebook/opt-1.3b \
  --swap-space 32 \
  --disable-log-requests \
  --schedule-type opt-xxx \
  --enable-chunked-prefill \
  --enforce-eager \
  --prefill-predictor-model-config MODEL/results/opt-125m-llama3-8b-lmsys-score-trainbucket10-b32/usage_config.json \
  --port 3343 &
```

### LTR / opt-xxx benchmark

```bash
DATASET=$(ls lmsys-Meta-Llama-3-8B-Instruct-*c10000*.jsonl | head -n 1)

python benchmark_serving_real.py \
  --backend vllm \
  --model facebook/opt-1.3b \
  --tokenizer facebook/opt-1.3b \
  --dataset "$DATASET" \
  --num-prompts 20 \
  --request-time 30 \
  --schedule-type opt-xxx \
  --output-len 128 \
  --request-rate 2 \
  --result-dir RESULTS \
  --port 3343
```

### Stop server

```bash
pkill -f "api_server"
```

## 6. Recommended next step

Use this smoke test as evidence that the experiment pipeline is valid. The next step is to run the formal `Meta-Llama-3-8B-Instruct` FCFS vs LTR reproduction and then compare request rates such as 2, 4, 8, 16, and 32 qps.
